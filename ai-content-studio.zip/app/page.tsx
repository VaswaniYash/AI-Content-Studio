"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, ImageIcon, Mic, FileText, Sparkles } from "lucide-react"
import { AIChatInterface } from "@/components/ai-chat-interface"
import { AIImageGenerator } from "@/components/ai-image-generator"
import { SpeechToText } from "@/components/speech-to-text"
import { AIContentSummarizer } from "@/components/ai-content-summarizer"

export default function AIContentStudio() {
  const [activeTab, setActiveTab] = useState("chat")

  const components = [
    {
      id: "chat",
      title: "AI Chat Interface",
      description: "Real-time chat with streaming AI responses",
      icon: MessageSquare,
      badge: "Streaming",
      component: AIChatInterface,
    },
    {
      id: "image",
      title: "AI Image Generator",
      description: "Generate images with DALL-E and custom parameters",
      icon: ImageIcon,
      badge: "DALL-E",
      component: AIImageGenerator,
    },
    {
      id: "speech",
      title: "Speech-to-Text",
      description: "Real-time voice transcription and commands",
      icon: Mic,
      badge: "Voice",
      component: SpeechToText,
    },
    {
      id: "summarizer",
      title: "Content Summarizer",
      description: "AI-powered document analysis and summarization",
      icon: FileText,
      badge: "GPT-4",
      component: AIContentSummarizer,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="h-8 w-8 text-blue-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AI Content Studio
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A comprehensive collection of AI-powered UI components for modern web applications. Built for the EmpireUI
            hackathon with cutting-edge AI integrations.
          </p>
        </div>

        {/* Component Grid Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {components.map((comp) => {
            const Icon = comp.icon
            return (
              <Card
                key={comp.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                  activeTab === comp.id ? "ring-2 ring-blue-500 shadow-lg" : ""
                }`}
                onClick={() => setActiveTab(comp.id)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <Icon className="h-6 w-6 text-blue-600" />
                    <Badge variant="secondary">{comp.badge}</Badge>
                  </div>
                  <CardTitle className="text-lg">{comp.title}</CardTitle>
                  <CardDescription className="text-sm">{comp.description}</CardDescription>
                </CardHeader>
              </Card>
            )
          })}
        </div>

        {/* Main Component Display */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            {components.map((comp) => {
              const Icon = comp.icon
              return (
                <TabsTrigger key={comp.id} value={comp.id} className="flex items-center gap-2">
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{comp.title.split(" ")[0]}</span>
                </TabsTrigger>
              )
            })}
          </TabsList>

          {components.map((comp) => {
            const Component = comp.component
            return (
              <TabsContent key={comp.id} value={comp.id} className="mt-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <comp.icon className="h-6 w-6 text-blue-600" />
                      <div>
                        <CardTitle>{comp.title}</CardTitle>
                        <CardDescription>{comp.description}</CardDescription>
                      </div>
                      <Badge variant="outline" className="ml-auto">
                        {comp.badge}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Component />
                  </CardContent>
                </Card>
              </TabsContent>
            )
          })}
        </Tabs>

        {/* Footer */}
        <div className="text-center mt-12 pt-8 border-t">
          <p className="text-sm text-muted-foreground">
            Built for EmpireUI Hackathon • Powered by AI SDK, OpenAI, and Next.js
          </p>
        </div>
      </div>
    </div>
  )
}
