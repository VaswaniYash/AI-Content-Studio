import { createGroq } from "@ai-sdk/groq"
import { generateText } from "ai"
import { NextResponse } from "next/server"

const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

export async function POST(req: Request) {
  try {
    const { text, type } = await req.json()

    const prompts = {
      concise: "Summarize the following text in 2-3 clear, concise sentences:",
      detailed: "Provide a detailed summary of the following text in one comprehensive paragraph:",
      bullet: "Summarize the following text as bullet points, highlighting the key information:",
      executive:
        "Create an executive summary of the following text, focusing on key insights and actionable information:",
    }

    const { text: summary } = await generateText({
      model: groq("llama-3.1-70b-versatile"),
      prompt: `${prompts[type as keyof typeof prompts]}\n\n${text}`,
    })

    return NextResponse.json({ summary })
  } catch (error) {
    console.error("Error summarizing content:", error)
    return NextResponse.json({ error: "Failed to summarize content" }, { status: 500 })
  }
}
