"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Upload, FileText, Loader2, Copy } from "lucide-react"

interface Summary {
  id: string
  originalText: string
  summary: string
  summaryType: string
  timestamp: Date
  wordCount: {
    original: number
    summary: number
  }
}

export function AIContentSummarizer() {
  const [inputText, setInputText] = useState("")
  const [summaryType, setSummaryType] = useState("concise")
  const [isProcessing, setIsProcessing] = useState(false)
  const [summaries, setSummaries] = useState<Summary[]>([])

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type === "text/plain") {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        setInputText(content)
      }
      reader.readAsText(file)
    }
  }

  const handleSummarize = async () => {
    if (!inputText.trim()) return

    setIsProcessing(true)
    try {
      const response = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: inputText,
          type: summaryType,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const newSummary: Summary = {
          id: Date.now().toString(),
          originalText: inputText,
          summary: data.summary,
          summaryType,
          timestamp: new Date(),
          wordCount: {
            original: inputText.split(" ").length,
            summary: data.summary.split(" ").length,
          },
        }
        setSummaries((prev) => [newSummary, ...prev])
        setInputText("")
      }
    } catch (error) {
      console.error("Error summarizing content:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const getCompressionRatio = (original: number, summary: number) => {
    return Math.round(((original - summary) / original) * 100)
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Input Section */}
      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">Content to Summarize</Label>
            <Textarea
              id="content"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your text here or upload a file..."
              className="min-h-[200px]"
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Label>Summary Type</Label>
              <Select value={summaryType} onValueChange={setSummaryType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="concise">Concise (2-3 sentences)</SelectItem>
                  <SelectItem value="detailed">Detailed (1 paragraph)</SelectItem>
                  <SelectItem value="bullet">Bullet Points</SelectItem>
                  <SelectItem value="executive">Executive Summary</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Upload File</Label>
              <div className="flex items-center gap-2">
                <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" id="file-upload" />
                <Button variant="outline" asChild>
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload .txt
                  </label>
                </Button>
              </div>
            </div>
          </div>

          <Button onClick={handleSummarize} disabled={isProcessing || !inputText.trim()} className="w-full">
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Summarizing...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Generate Summary
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Summaries */}
      {summaries.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium text-muted-foreground">No summaries yet</p>
            <p className="text-sm text-muted-foreground">Add some content above to generate your first AI summary</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {summaries.map((summary) => (
            <Card key={summary.id}>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{summary.summaryType}</Badge>
                      <Badge variant="secondary">
                        {getCompressionRatio(summary.wordCount.original, summary.wordCount.summary)}% shorter
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button onClick={() => copyToClipboard(summary.summary)} variant="ghost" size="sm">
                        <Copy className="h-4 w-4" />
                      </Button>
                      <span className="text-xs text-muted-foreground">{summary.timestamp.toLocaleDateString()}</span>
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm font-medium">Summary</Label>
                      <div className="mt-1 p-3 bg-muted rounded-md">
                        <p className="text-sm whitespace-pre-wrap">{summary.summary}</p>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>Original: {summary.wordCount.original} words</span>
                      <span>Summary: {summary.wordCount.summary} words</span>
                      <span>
                        Compression: {getCompressionRatio(summary.wordCount.original, summary.wordCount.summary)}%
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
