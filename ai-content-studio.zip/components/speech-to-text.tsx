"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Mic, MicOff, Volume2, Copy, Trash2 } from "lucide-react"

interface TranscriptionEntry {
  id: string
  text: string
  timestamp: Date
  confidence?: number
}

declare global {
  interface Window {
    SpeechRecognition: any
    webkitSpeechRecognition: any
  }
}

export function SpeechToText() {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [transcriptions, setTranscriptions] = useState<TranscriptionEntry[]>([])
  const [isSupported, setIsSupported] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      setIsSupported(!!SpeechRecognition)

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition()
        recognition.continuous = true
        recognition.interimResults = true
        recognition.lang = "en-US"

        recognition.onresult = (event) => {
          let finalTranscript = ""
          let interimTranscript = ""

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript
            if (event.results[i].isFinal) {
              finalTranscript += transcript
            } else {
              interimTranscript += transcript
            }
          }

          setTranscript(finalTranscript + interimTranscript)

          if (finalTranscript) {
            const newEntry: TranscriptionEntry = {
              id: Date.now().toString(),
              text: finalTranscript.trim(),
              timestamp: new Date(),
              confidence: event.results[event.results.length - 1][0].confidence,
            }
            setTranscriptions((prev) => [newEntry, ...prev])
          }
        }

        recognition.onerror = (event) => {
          console.error("Speech recognition error:", event.error)
          setIsListening(false)
        }

        recognition.onend = () => {
          setIsListening(false)
        }

        recognitionRef.current = recognition
      }
    }
  }, [])

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setTranscript("")
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const clearTranscriptions = () => {
    setTranscriptions([])
    setTranscript("")
  }

  if (!isSupported) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <MicOff className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium text-muted-foreground">Speech Recognition Not Supported</p>
          <p className="text-sm text-muted-foreground">
            Your browser doesn't support the Web Speech API. Try using Chrome or Edge.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Recording Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Button
              onClick={isListening ? stopListening : startListening}
              size="lg"
              className={`h-16 w-16 rounded-full ${
                isListening ? "bg-red-600 hover:bg-red-700 animate-pulse" : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {isListening ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
            </Button>
            <div className="text-center">
              <p className="font-medium">{isListening ? "Listening..." : "Click to start recording"}</p>
              <Badge variant={isListening ? "destructive" : "secondary"}>{isListening ? "Recording" : "Stopped"}</Badge>
            </div>
          </div>

          {/* Live Transcript */}
          {transcript && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Live Transcript:</label>
              <Textarea
                value={transcript}
                readOnly
                className="min-h-[100px] bg-muted"
                placeholder="Your speech will appear here..."
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transcription History */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Transcription History</h3>
            {transcriptions.length > 0 && (
              <Button onClick={clearTranscriptions} variant="outline" size="sm">
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            )}
          </div>

          {transcriptions.length === 0 ? (
            <div className="text-center py-8">
              <Volume2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">No transcriptions yet</p>
              <p className="text-sm text-muted-foreground">Start speaking to see your transcriptions here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {transcriptions.map((entry) => (
                <Card key={entry.id} className="bg-muted/50">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <p className="text-sm mb-2">{entry.text}</p>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {entry.timestamp.toLocaleTimeString()}
                          </Badge>
                          {entry.confidence && (
                            <Badge variant="secondary" className="text-xs">
                              {Math.round(entry.confidence * 100)}% confidence
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button onClick={() => copyToClipboard(entry.text)} variant="ghost" size="sm">
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
