"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Loader2, Download, Sparkles, ImageIcon } from "lucide-react"

interface GeneratedImage {
  url: string
  prompt: string
  timestamp: Date
}

export function AIImageGenerator() {
  const [prompt, setPrompt] = useState("")
  const [size, setSize] = useState("1024x1024")
  const [style, setStyle] = useState("natural")
  const [quality, setQuality] = useState("standard")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([])

  const handleGenerate = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)
    try {
      // For demo purposes, we'll use a placeholder image service
      // In a real implementation, you could use:
      // - Replicate API (Stable Diffusion)
      // - Hugging Face Inference API
      // - Local Stable Diffusion

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate a placeholder image URL with the prompt
      const imageUrl = `/placeholder.svg?height=512&width=512&text=${encodeURIComponent(prompt.slice(0, 50))}`

      const newImage: GeneratedImage = {
        url: imageUrl,
        prompt,
        timestamp: new Date(),
      }
      setGeneratedImages((prev) => [newImage, ...prev])
      setPrompt("")
    } catch (error) {
      console.error("Error generating image:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Generation Form */}
      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt">Image Prompt</Label>
            <Textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to generate..."
              className="min-h-[100px]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Size</Label>
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1024x1024">Square (1024×1024)</SelectItem>
                  <SelectItem value="1024x1792">Portrait (1024×1792)</SelectItem>
                  <SelectItem value="1792x1024">Landscape (1792×1024)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Style</Label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="natural">Natural</SelectItem>
                  <SelectItem value="vivid">Vivid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Quality</Label>
              <Select value={quality} onValueChange={setQuality}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="hd">HD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleGenerate} disabled={isGenerating || !prompt.trim()} className="w-full">
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Image
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Images */}
      {generatedImages.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <ImageIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium text-muted-foreground">No images generated yet</p>
            <p className="text-sm text-muted-foreground">Enter a prompt above to create your first AI image</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {generatedImages.map((image, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="aspect-square relative">
                <img src={image.url || "/placeholder.svg"} alt={image.prompt} className="w-full h-full object-cover" />
              </div>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{image.prompt}</p>
                <div className="flex items-center justify-between">
                  <Badge variant="secondary">{image.timestamp.toLocaleDateString()}</Badge>
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
